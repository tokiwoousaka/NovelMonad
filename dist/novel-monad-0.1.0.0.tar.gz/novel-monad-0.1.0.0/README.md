NovelMonad
==========

Monad for novel game story by opelational monad.
